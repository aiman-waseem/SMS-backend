// Generate Access Token for user
// export const generateAccessToken = async (user) => {
//   try {
//     // config.get("TOKEN_KEY")
//     const jwtTime = await Configuration.findOne({ where: { keyName: "JWTExpiry" }, raw: true });
//     return jwt.sign(user, process.env.TOKEN_KEY, {
//       expiresIn: jwtTime?.value || "9h",
//       algorithm: "HS256", // Explicitly using HS256 algorithm
//     });
//   } catch (error) {
//     console.error("Error generating token:", error);
//     return null;
//   }
// };
import jwt from "jsonwebtoken";
export const generateAccessToken = (user) => {
    console.log("Inside token obj", user)
    try{
 return jwt.sign(user, process.env.TOKEN_KEY, {
    expiresIn: "10h",
    algorithm: "HS256",
  })
    } catch(error){
        console.error("Error generating token:", error);
        return null;
    }
 
};