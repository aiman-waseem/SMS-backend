import { authRoutes } from "./modules/auth/routes/index.js";


export const allRoutes = (fastify, options, done) => {
  fastify.register(authRoutes, { prefix: "/auth" });
  done()
}